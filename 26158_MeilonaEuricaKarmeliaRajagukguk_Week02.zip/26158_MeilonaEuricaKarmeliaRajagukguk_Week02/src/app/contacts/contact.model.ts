export interface Contact {
    id: string;
    name: string;
    imageUrl: string;
    phoneNumber: string[];
    email: string[];
}
